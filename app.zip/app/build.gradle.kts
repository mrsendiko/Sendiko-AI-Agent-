plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.sendiko.agent"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.sendiko.agent"
        minSdk = 26
        targetSdk = 32
        versionCode = 1
        versionName = "1.0-prototype"
    }
}
