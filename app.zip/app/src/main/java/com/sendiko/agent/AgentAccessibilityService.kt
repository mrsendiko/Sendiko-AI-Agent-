package com.sendiko.agent

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Prototype only. No automatic clicks or typing are executed yet.
 * Future actions must be based on an approved task plan and safety confirmation.
 */
class AgentAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally passive in v1 prototype.
        // The service does not collect or transmit screen contents.
    }
    override fun onInterrupt() {}
}
