package com.sendiko.agent

import android.content.Context
import android.app.AlertDialog

object AlertDialogHelper {
    fun show(context: Context, title: String, message: String) {
        AlertDialog.Builder(context).setTitle(title).setMessage(message).setPositiveButton("Mengerti", null).show()
    }
}
