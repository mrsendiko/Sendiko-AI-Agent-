package com.sendiko.agent

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.*
import android.view.ViewGroup
import android.graphics.Color

class MainActivity : Activity() {
    private val PICK_VIDEO = 1001
    private var selectedVideo: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(Color.rgb(20, 20, 38))
        }
        fun text(value: String, size: Float, color: Int = Color.WHITE): TextView =
            TextView(this).apply { text = value; textSize = size; setTextColor(color); setPadding(0, 10, 0, 10) }
        fun button(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }
        }

        layout.addView(text("SENDIKO AI AGENT", 26f))
        layout.addView(text("Asisten Android • Mode Mandiri dengan Konfirmasi", 14f, Color.LTGRAY))
        layout.addView(text("Status: PROTOTIPE — belum terhubung ke mesin AI", 13f, 0xFFFFCC66.toInt()))
        layout.addView(button("1. Pilih video pembelajaran") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "video/*"
            }
            startActivityForResult(intent, PICK_VIDEO)
        })
        layout.addView(button("2. Siapkan akses kontrol Android") {
            startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        layout.addView(button("3. Perintah Agent (demo)") {
            AlertDialogHelper.show(this,
                "Fitur belum aktif",
                "Analisis video dan eksekusi AI belum dihubungkan. Prototipe ini baru menyiapkan pemilih video dan pintu izin aksesibilitas.")
        })
        layout.addView(text("Video dipilih:", 16f))
        val videoLabel = text("Belum ada video", 13f, Color.LTGRAY)
        layout.addView(videoLabel)
        layout.addView(text("Keamanan: Agent harus meminta persetujuan sebelum mengirim, menghapus, membeli, membayar, atau memublikasikan sesuatu.", 13f, Color.LTGRAY))
        setContentView(layout)
        videoLabel.tag = "videoLabel"
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK) {
            selectedVideo = data?.data
            val label = findViewByTag(window.decorView, "videoLabel") as? TextView
            label?.text = selectedVideo?.lastPathSegment ?: "Video dipilih"
            selectedVideo?.let { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        }
    }

    private fun findViewByTag(view: android.view.View, tag: String): android.view.View? {
        if (view.tag == tag) return view
        if (view is ViewGroup) for (i in 0 until view.childCount) findViewByTag(view.getChildAt(i), tag)?.let { return it }
        return null
    }
}
